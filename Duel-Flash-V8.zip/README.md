# Duel Flash

Prototype Android de mini-jeux rapides jouables à deux sur le même téléphone.

## Modes disponibles

- **Trouve l'intrus** : repérer le symbole différent avant la fin du chrono.
- **Stop Chrono** : arrêter le compteur au plus près de la cible.

## Version 0.2

- 10 univers visuels pour Trouve l'intrus.
- Grilles et difficulté progressives.
- Résultat détaillé après chaque Stop Chrono : cible, temps réel, écart et points.
- Écran de validation entre chaque joueur.
- Nouvelle icône Duel Flash.

## Version 0.3

- Tableau de scores permanent et joueur actif mis en valeur.
- Scores actualisés après le tour de chaque joueur.
- Nouveau fond dégradé et cartes translucides.
- Compteur circulaire pour Stop Chrono.
- Chronomètre et écrans de résultat plus lisibles.

## Version 0.4

- Nouvel accueil arcade électrique et logo repensé.
- Mode Intrus Rush de 20 secondes avec combos, pénalités et Fever.
- Célébrations Perfect, Incroyable et Presque pour Stop Chrono.
- Pseudonymes et Top 10 local persistant pour chaque jeu.
- Signature de développement stable pour les futures mises à jour de test.

## Version 0.5

- Deux durées pour Intrus Rush : Flash 30 secondes et Endurance 1 minute.
- Classements Top 10 séparés pour chaque durée.

## Version 0.6

- Mode Solo libre pour battre son record.
- Parcours Solo de 50 niveaux avec objectifs progressifs et sauvegarde des niveaux débloqués.
- Duels contre l'ordinateur avec trois difficultés : Facile, Normal et Difficile.
- Mode local à deux joueurs conservé pour jouer sur le même téléphone.
- Écrans et boutons adaptés automatiquement au mode choisi.

## Version 0.7

- Révélation visuelle de l'intrus après une erreur et à la fin du Rush.
- Passage direct au niveau suivant après une réussite.
- Félicitations élargies et combos de précision dans Stop Chrono.
- Ordinateur Stop Chrono renforcé et score mis à jour à chaque manche.
- Libellé Ordinateur clairement affiché dans les duels.

## Version 0.8

- Nouvelle courbe de difficulté sur 50 niveaux, construite à partir des scores de test.
- Niveau défi tous les 5 niveaux et objectifs distincts pour chaque jeu et chaque durée.
- Ordinateur Intrus Rush adapté aux gros combos et à la performance du joueur.
- Révélation de l'intrus renforcée avec pulsation, contour et message visible.
- Pseudonymes mémorisés automatiquement.
- Icône Stop Chrono plus lisible sur l'écran de choix du mode.

Stop Chrono se joue en 5 manches. Intrus Rush se joue pendant 30 secondes ou 1 minute.

## Ouvrir le projet

1. Installer Android Studio.
2. Ouvrir le dossier du projet.
3. Laisser Android Studio synchroniser Gradle.
4. Lancer l'application sur un téléphone ou un émulateur Android 8.0 ou supérieur.

## Technique

- Kotlin
- Jetpack Compose
- Android 8.0+ (API 26)
